var _slope_limit_behavior_8cs =
[
    [ "SlopeLimitBehavior", "class_easy_character_movement_1_1_slope_limit_behavior.html", "class_easy_character_movement_1_1_slope_limit_behavior" ],
    [ "SlopeBehaviour", "_slope_limit_behavior_8cs.html#af4ab8ec856d9ff49ea50de4c9249a99e", [
      [ "Default", "_slope_limit_behavior_8cs.html#af4ab8ec856d9ff49ea50de4c9249a99ea7a1920d61156abc05a60135aefe8bc67", null ],
      [ "Walkable", "_slope_limit_behavior_8cs.html#af4ab8ec856d9ff49ea50de4c9249a99ea69266ac9c6970974587fe7f8b6b3c0a4", null ],
      [ "NotWalkable", "_slope_limit_behavior_8cs.html#af4ab8ec856d9ff49ea50de4c9249a99ea6d2d20b30b19015957a3e0c594edad22", null ],
      [ "Override", "_slope_limit_behavior_8cs.html#af4ab8ec856d9ff49ea50de4c9249a99ea6da8e67225fdcfa78c3ea5dc3154b849", null ]
    ] ]
];