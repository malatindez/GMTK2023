var indexSectionsWithContent =
{
  0: "_abcdefghijlmnoprstuvwz",
  1: "acefimprst",
  2: "e",
  3: "acefimprst",
  4: "acdefghijlmnoprstuwz",
  5: "_cdeghimnoprsv",
  6: "chmprs",
  7: "abcdfnosw",
  8: "abcdefghijlmnprstuvwz",
  9: "cfjlmprsuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties",
  9: "Events"
};

