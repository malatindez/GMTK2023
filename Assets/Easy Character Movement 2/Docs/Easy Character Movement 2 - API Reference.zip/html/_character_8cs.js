var _character_8cs =
[
    [ "Character", "class_easy_character_movement_1_1_character.html", "class_easy_character_movement_1_1_character" ],
    [ "MovementMode", "_character_8cs.html#a40f6935bcb94bcbbfb7fa108c56cc83b", [
      [ "None", "_character_8cs.html#a40f6935bcb94bcbbfb7fa108c56cc83ba6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Walking", "_character_8cs.html#a40f6935bcb94bcbbfb7fa108c56cc83badb6ea77c7cd8a86b17014c3b688fd1a1", null ],
      [ "Falling", "_character_8cs.html#a40f6935bcb94bcbbfb7fa108c56cc83ba0f57d5b441651c57eac9f91efaa5a75a", null ],
      [ "Swimming", "_character_8cs.html#a40f6935bcb94bcbbfb7fa108c56cc83ba7b7a0411718cea15c3f9dc675af1b7c7", null ],
      [ "Flying", "_character_8cs.html#a40f6935bcb94bcbbfb7fa108c56cc83ba444733081a578880ba8a563d3c59d22d", null ],
      [ "Custom", "_character_8cs.html#a40f6935bcb94bcbbfb7fa108c56cc83ba90589c47f06eb971d548591f23c285af", null ]
    ] ],
    [ "RotationMode", "_character_8cs.html#ac95d200b285f2996326b80cef553ed66", [
      [ "None", "_character_8cs.html#ac95d200b285f2996326b80cef553ed66a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "OrientToMovement", "_character_8cs.html#ac95d200b285f2996326b80cef553ed66a898065440af2bd238570087d22409f44", null ],
      [ "OrientToCameraViewDirection", "_character_8cs.html#ac95d200b285f2996326b80cef553ed66aa717cfc6017e306fd0380daf1ed39b3c", null ],
      [ "OrientWithRootMotion", "_character_8cs.html#ac95d200b285f2996326b80cef553ed66ac148b3835466cc215cb73572ddf6a00a", null ],
      [ "Custom", "_character_8cs.html#ac95d200b285f2996326b80cef553ed66a90589c47f06eb971d548591f23c285af", null ]
    ] ]
];