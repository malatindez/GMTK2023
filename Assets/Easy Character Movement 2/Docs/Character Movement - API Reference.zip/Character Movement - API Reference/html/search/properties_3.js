var searchData=
[
  ['fastplatformmove_299',['fastPlatformMove',['../class_easy_character_movement_1_1_character_movement.html#ad4c062daa2deae06b234f99d6452da93',1,'EasyCharacterMovement::CharacterMovement']]],
  ['forwardspeed_300',['forwardSpeed',['../class_easy_character_movement_1_1_character_movement.html#ab9a17f490e06948fb618c4fcf7367ef7',1,'EasyCharacterMovement::CharacterMovement']]]
];
