var searchData=
[
  ['collider_243',['collider',['../struct_easy_character_movement_1_1_find_ground_result.html#a912542a06265c0278071719967a6759b',1,'EasyCharacterMovement.FindGroundResult.collider()'],['../struct_easy_character_movement_1_1_collision_result.html#a5a220b4badea8acfd6ee454335760f15',1,'EasyCharacterMovement.CollisionResult.collider()']]]
];
