var searchData=
[
  ['ignorecollision_208',['IgnoreCollision',['../class_easy_character_movement_1_1_character_movement.html#ac9b6213c32151c3b948cfce780309eff',1,'EasyCharacterMovement.CharacterMovement.IgnoreCollision(Collider otherCollider, bool ignore=true)'],['../class_easy_character_movement_1_1_character_movement.html#a51b413382ec3c7a0bc588d08b39bdcae',1,'EasyCharacterMovement.CharacterMovement.IgnoreCollision(Rigidbody otherRigidbody, bool ignore=true)']]],
  ['isexceeding_209',['isExceeding',['../class_easy_character_movement_1_1_extensions.html#ab7662de9ebffbd9265a634d45cfd638a',1,'EasyCharacterMovement::Extensions']]],
  ['iswithinedgetolerance_210',['IsWithinEdgeTolerance',['../class_easy_character_movement_1_1_character_movement.html#afdd31756361cb0327b02216f80b0cfee',1,'EasyCharacterMovement::CharacterMovement']]],
  ['iszero_211',['isZero',['../class_easy_character_movement_1_1_extensions.html#a38d907056e51b605765691a92fb64222',1,'EasyCharacterMovement.Extensions.isZero(this float value)'],['../class_easy_character_movement_1_1_extensions.html#a5160cda07bce1f9659f4f45a677f1815',1,'EasyCharacterMovement.Extensions.isZero(this Vector2 vector2)'],['../class_easy_character_movement_1_1_extensions.html#af4a7e25891cf0d05dfe1b22bf4b162f0',1,'EasyCharacterMovement.Extensions.isZero(this Vector3 vector3)']]]
];
