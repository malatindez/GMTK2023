var searchData=
[
  ['minmovedistancesqr_320',['minMoveDistanceSqr',['../struct_easy_character_movement_1_1_character_movement_1_1_advanced.html#a1b602f26cc777ebb5111f2e0e53c2cd6',1,'EasyCharacterMovement::CharacterMovement::Advanced']]]
];
