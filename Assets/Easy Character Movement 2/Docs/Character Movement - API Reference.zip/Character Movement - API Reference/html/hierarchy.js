var hierarchy =
[
    [ "EasyCharacterMovement.CharacterMovement.Advanced", "struct_easy_character_movement_1_1_character_movement_1_1_advanced.html", null ],
    [ "EasyCharacterMovement.CollisionResult", "struct_easy_character_movement_1_1_collision_result.html", null ],
    [ "EasyCharacterMovement.Extensions", "class_easy_character_movement_1_1_extensions.html", null ],
    [ "EasyCharacterMovement.FindGroundResult", "struct_easy_character_movement_1_1_find_ground_result.html", null ],
    [ "EasyCharacterMovement.MeshUtility", "class_easy_character_movement_1_1_mesh_utility.html", null ],
    [ "MonoBehaviour", null, [
      [ "EasyCharacterMovement.CharacterMovement", "class_easy_character_movement_1_1_character_movement.html", null ],
      [ "EasyCharacterMovement.SlopeLimitBehavior", "class_easy_character_movement_1_1_slope_limit_behavior.html", null ]
    ] ]
];